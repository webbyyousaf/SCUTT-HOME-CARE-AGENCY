/* ===================================================================
   SCUTT HOME CARE AGENCY — MAIN SCRIPT
   No backend required. Handles: mobile nav, FAQ chat widget,
   accordion, and the dual-submit contact/quote form (mailto + WhatsApp).
   =================================================================== */

(function () {
  "use strict";

  /* ---------- BUSINESS CONSTANTS (edit here once, used everywhere) ---------- */
  const BUSINESS = {
    phoneDisplay: "(267) 748-9706",
    phoneHref: "+12677489706",
    whatsappNumber: "12677489706", // wa.me format, no plus, no spaces
    email: "widlynne@gmail.com",
    name: "Scutt Home Care Agency"
  };
  window.SCUTT_BUSINESS = BUSINESS;

  /* ---------- MOBILE NAV TOGGLE ---------- */
  const navToggle = document.querySelector(".nav-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (navToggle && navLinks) {
    navToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
      });
    });
  }

  /* ---------- ACCORDION (FAQ pages) ---------- */
  document.querySelectorAll(".accordion-trigger").forEach((trigger) => {
    trigger.addEventListener("click", () => {
      const panel = document.getElementById(trigger.getAttribute("aria-controls"));
      const expanded = trigger.getAttribute("aria-expanded") === "true";

      // close siblings within the same accordion group for a cleaner UX
      const group = trigger.closest(".accordion");
      if (group) {
        group.querySelectorAll(".accordion-trigger").forEach((t) => {
          if (t !== trigger) {
            t.setAttribute("aria-expanded", "false");
            const p = document.getElementById(t.getAttribute("aria-controls"));
            if (p) p.style.maxHeight = null;
          }
        });
      }

      trigger.setAttribute("aria-expanded", expanded ? "false" : "true");
      if (panel) panel.style.maxHeight = expanded ? null : panel.scrollHeight + "px";
    });
  });

  /* ---------- CONTACT / QUOTE FORM — DUAL SUBMIT (mailto + WhatsApp) ---------- */
  function buildMessageBody(data) {
    return (
      "New inquiry from the website\n\n" +
      "Name: " + data.name + "\n" +
      "Email: " + data.email + "\n" +
      "Phone: " + data.phone + "\n" +
      (data.service ? "Service interested in: " + data.service + "\n" : "") +
      (data.preferredDate ? "Preferred date/time: " + data.preferredDate + "\n" : "") +
      "\nMessage:\n" + data.message
    );
  }

  function getFormData(form) {
    const fd = new FormData(form);
    return {
      name: (fd.get("name") || "").toString().trim(),
      email: (fd.get("email") || "").toString().trim(),
      phone: (fd.get("phone") || "").toString().trim(),
      service: (fd.get("service") || "").toString().trim(),
      preferredDate: (fd.get("preferredDate") || "").toString().trim(),
      message: (fd.get("message") || "").toString().trim()
    };
  }

  function validate(data, form) {
    let valid = true;
    const requiredFields = ["name", "email", "phone", "message"];
    requiredFields.forEach((field) => {
      const input = form.querySelector('[name="' + field + '"]');
      if (!input) return;
      if (!data[field]) {
        input.style.borderColor = "#C0392B";
        valid = false;
      } else {
        input.style.borderColor = "";
      }
    });
    return valid;
  }

  function initContactForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;

    const emailBtn = form.querySelector('[data-action="email"]');
    const whatsappBtn = form.querySelector('[data-action="whatsapp"]');

    if (emailBtn) {
      emailBtn.addEventListener("click", () => {
        const data = getFormData(form);
        if (!validate(data, form)) return;
        const subject = encodeURIComponent(
          (data.service ? data.service + " — " : "") + "Website Inquiry from " + data.name
        );
        const body = encodeURIComponent(buildMessageBody(data));
        window.location.href =
          "mailto:" + BUSINESS.email + "?subject=" + subject + "&body=" + body;
      });
    }

    if (whatsappBtn) {
      whatsappBtn.addEventListener("click", () => {
        const data = getFormData(form);
        if (!validate(data, form)) return;
        const text = encodeURIComponent(buildMessageBody(data));
        window.open("https://wa.me/" + BUSINESS.whatsappNumber + "?text=" + text, "_blank");
      });
    }

    // Prevent native submission (no backend) — buttons above handle everything
    form.addEventListener("submit", (e) => e.preventDefault());
  }

  initContactForm("contactForm");
  initContactForm("quoteForm");

  /* ---------- FAQ CHAT WIDGET ---------- */
  const FAQ_TREE = {
    root: {
      bot: "Hello, I'm the Scutt Home Care virtual assistant. What can I help you with today?",
      options: [
        { label: "What services do you offer?", next: "services" },
        { label: "Do you accept insurance?", next: "insurance" },
        { label: "How do I get started?", next: "getstarted" },
        { label: "What areas do you serve?", next: "areas" },
        { label: "Talk to a real person", next: "human" }
      ]
    },
    services: {
      bot: "We provide licensed home health care, including skilled nursing visits, physical/occupational/speech therapy, home health aide support, and medical social services — all delivered in the comfort of your home. Would you like to see our full services page or get a quote?",
      options: [
        { label: "View Services page", href: "services.html" },
        { label: "Get a free quote", href: "book-appointment.html" },
        { label: "Back to menu", next: "root" }
      ]
    },
    insurance: {
      bot: "We work with Medicare, Medicaid, and most major insurance plans. Coverage depends on your specific plan and physician orders. Our team will verify your benefits for you at no cost before care begins.",
      options: [
        { label: "Ask about my specific plan", href: "contact.html" },
        { label: "Back to menu", next: "root" }
      ]
    },
    getstarted: {
      bot: "Getting started is simple: (1) Request a free consultation, (2) We coordinate with your physician for orders, (3) A nurse completes an in-home assessment, (4) We build your personalized care plan and begin visits.",
      options: [
        { label: "Book a consultation", href: "book-appointment.html" },
        { label: "Back to menu", next: "root" }
      ]
    },
    areas: {
      bot: "We proudly serve Philadelphia, PA and surrounding communities. If you're unsure whether we cover your area, just reach out and our team will confirm right away.",
      options: [
        { label: "Contact us", href: "contact.html" },
        { label: "Back to menu", next: "root" }
      ]
    },
    human: {
      bot: "Of course — you can reach our office directly and we'll be happy to help.",
      options: [
        { label: "Call " + BUSINESS.phoneDisplay, href: "tel:" + BUSINESS.phoneHref },
        { label: "Chat on WhatsApp", href: "https://wa.me/" + BUSINESS.whatsappNumber },
        { label: "Back to menu", next: "root" }
      ]
    }
  };

  const chatLauncher = document.getElementById("chatLauncher");
  const chatWindow = document.getElementById("chatWindow");
  const chatClose = document.getElementById("chatClose");
  const chatBody = document.getElementById("chatBody");
  const chatOptions = document.getElementById("chatOptions");

  function renderNode(nodeKey, addUserEcho) {
    const node = FAQ_TREE[nodeKey];
    if (!node) return;

    if (addUserEcho) {
      const userBubble = document.createElement("div");
      userBubble.className = "chat-bubble user";
      userBubble.textContent = addUserEcho;
      chatBody.appendChild(userBubble);
    }

    const botBubble = document.createElement("div");
    botBubble.className = "chat-bubble bot";
    botBubble.textContent = node.bot;
    chatBody.appendChild(botBubble);
    chatBody.scrollTop = chatBody.scrollHeight;

    chatOptions.innerHTML = "";
    node.options.forEach((opt) => {
      const btn = document.createElement(opt.href ? "a" : "button");
      btn.className = "chat-option-btn";
      btn.textContent = opt.label;
      if (opt.href) {
        btn.href = opt.href;
        if (opt.href.startsWith("http") || opt.href.startsWith("tel") || opt.href.startsWith("mailto")) {
          btn.target = opt.href.startsWith("http") ? "_blank" : "_self";
        }
      } else {
        btn.type = "button";
        btn.addEventListener("click", () => renderNode(opt.next, opt.label));
      }
      chatOptions.appendChild(btn);
    });
  }

  if (chatLauncher && chatWindow) {
    let initialized = false;
    chatLauncher.addEventListener("click", () => {
      const isOpen = chatWindow.classList.toggle("open");
      chatLauncher.setAttribute("aria-expanded", isOpen ? "true" : "false");
      if (isOpen && !initialized) {
        renderNode("root");
        initialized = true;
      }
    });
    if (chatClose) {
      chatClose.addEventListener("click", () => {
        chatWindow.classList.remove("open");
        chatLauncher.setAttribute("aria-expanded", "false");
      });
    }
  }

  /* ---------- AUTO-FILL tel/whatsapp/mailto LINKS GLOBALLY ---------- */
  document.querySelectorAll("[data-call]").forEach((el) => {
    el.href = "tel:" + BUSINESS.phoneHref;
  });
  document.querySelectorAll("[data-whatsapp]").forEach((el) => {
    const presetText = el.getAttribute("data-whatsapp") || "Hello, I'd like to ask about home health care services.";
    el.href = "https://wa.me/" + BUSINESS.whatsappNumber + "?text=" + encodeURIComponent(presetText);
  });
  document.querySelectorAll("[data-email]").forEach((el) => {
    el.href = "mailto:" + BUSINESS.email;
  });

  /* ---------- LAZY LOAD FALLBACK ATTRIBUTE ---------- */
  document.querySelectorAll("img:not([loading])").forEach((img) => {
    img.setAttribute("loading", "lazy");
  });
})();
