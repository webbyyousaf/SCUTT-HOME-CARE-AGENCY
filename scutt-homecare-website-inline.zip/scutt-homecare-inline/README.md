# Scutt Home Care Agency — Website Package

A 9-page, mobile-first business website for Scutt Home Care Agency LLC
(Philadelphia, PA). Pure HTML/CSS/JS — no frameworks, no build step.

## Files

```
index.html              Home
about-us.html            About Us
about-owner.html         About Owner (Widlynne Pierre-Scutt)
services.html            Services (4 service sections)
goals-vision.html        Mission / Vision / Goals
contact.html             Contact form + FAQ accordion
book-appointment.html    Appointment / quote request form
privacy-policy.html      Privacy Policy
terms-conditions.html    Terms & Conditions
css/style.css            All styles (design tokens at the top)
js/main.js               Nav, chat widget, accordion, form logic
```

Open `index.html` directly in any browser — everything works with no server.

## Before going live — replace these placeholders

1. **Domain**: replace `https://www.scutthomecare.com/` in every `<link rel="canonical">`,
   Open Graph tag, and the JSON-LD schema block in `index.html` with the real domain.
2. **Images**: every visual is an inline SVG illustration (teal/gold, no stock photos).
   Swap in real photography by replacing the `<svg>...</svg>` block inside
   `.hero-visual`, `.owner-portrait`, and `.service-media` with an `<img>` tag.
   Keep `loading="lazy"` on any `<img>` you add.
3. **Business details**: phone, email, and WhatsApp number are centralized in
   `js/main.js` under the `BUSINESS` object at the top of the file — edit once,
   it updates every `data-call` / `data-whatsapp` / `data-email` link site-wide.
4. **Address**: search-replace "2123 McKinley St, Philadelphia, PA 19149" if it changes.
5. **Testimonials** on the homepage are placeholder names — replace with real client
   quotes (with permission) before launch.

## The dual-submit contact form (no backend)

Both `contact.html` and `book-appointment.html` use the same pattern:
- **Email button** → builds a `mailto:` link with subject + body pre-filled, opens
  the visitor's default email app.
- **WhatsApp button** → builds a `https://wa.me/<number>?text=...` link, opens
  WhatsApp Web/App in a new tab with the message pre-filled.

Both are handled in `js/main.js` inside `initContactForm()`. No server, database,
or form-processing service is required. If you later want submissions logged to
a database or email service, swap the button click-handlers for a `fetch()` call
to your endpoint of choice.

## FAQ chat widget

Bottom-right floating button on every page. Answers live in the `FAQ_TREE` object
in `js/main.js` — edit the `bot` text or `options` arrays to change what it says.
It's a fixed decision tree, not an AI — fully client-side, no API calls.

## WordPress conversion path

This was built so each page maps directly onto a WordPress structure:

**Option A — Fastest (Custom HTML / block theme + Custom HTML blocks)**
1. Create a Page in WP for each `.html` file (same slugs: `about-us`, `services`, etc.)
2. Paste the contents of `<main>...</main>` from each file into a single **Custom HTML**
   block (or several, split at each `<section>` if you want to mix in native Gutenberg
   blocks later).
3. Upload `css/style.css` via **Appearance → Customize → Additional CSS**, or enqueue
   it in your child theme's `functions.php`.
4. Upload `js/main.js` the same way, or add it via a plugin like "Insert Headers and Footers."
5. Rebuild the header/footer once as a WordPress template part (Site Editor) or in
   `header.php` / `footer.php` if using a classic theme — every page's header/footer
   HTML is byte-for-byte identical, so copy it from any one file.

**Option B — Native Gutenberg (more polished, more work)**
1. Recreate each `<section>` using core blocks: Group (for `.section`, `.section-tint`),
   Columns (for `.two-col`, `.grid-*`), Buttons (for `.btn-row`), and Cover (for `.hero`).
2. Convert the design tokens in `css/style.css` (`:root` block) into
   `theme.json` → `settings.color.palette` and `settings.typography.fontFamilies`
   so the same teal/gold/Fraunces system is available in the block editor's color
   and typography pickers.
3. Re-implement the FAQ chat widget and accordion as a **Custom HTML** block per page
   (they're self-contained and don't depend on any other JS).
4. Re-implement the contact/quote forms as Custom HTML blocks too — most form plugins
   (WPForms, Gravity Forms) handle server-side submission, which isn't needed here;
   only use one if you want submissions to also save to a database in addition to
   mailto/WhatsApp.

## SEO already in place

- One `<h1>` per page, logical `<h2>`/`<h3>` hierarchy
- Meta title + description on every page (edit per-page in `<head>`)
- `rel="canonical"` on every page
- `MedicalBusiness` JSON-LD schema on the homepage (update once domain is final)
- `loading="lazy"` auto-applied via JS to any image without an explicit attribute
- Semantic HTML5 (`<header>`, `<main>`, `<nav>`, `<footer>`, `<article>`)

## Accessibility notes

- Skip-to-content link on every page
- Visible focus states (gold outline) on all interactive elements
- `aria-expanded` / `aria-controls` wired up on the mobile nav, accordion, and chat widget
- `prefers-reduced-motion` respected (animations disabled automatically)
